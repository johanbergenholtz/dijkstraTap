package com.example.dijkstratap;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class LineDiagLR extends View {
    Paint paint = new Paint();

    public LineDiagLR(Context context) {

        super(context);
    }

    public LineDiagLR(Context context, AttributeSet attrs) {

        super(context, attrs);
    }

    public LineDiagLR(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas){
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(10f);
        canvas.drawLine(0,0,getWidth(),getHeight(), paint);

    }


}
