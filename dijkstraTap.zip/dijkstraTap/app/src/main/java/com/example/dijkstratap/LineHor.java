package com.example.dijkstratap;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class LineHor extends View {
    Paint paint = new Paint();

    public LineHor(Context context) {

        super(context);
    }

    public LineHor(Context context, AttributeSet attrs) {

        super(context, attrs);
    }

    public LineHor(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas){
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(10f);
        canvas.drawLine(0,getHeight()/2,getWidth(),getHeight()/2, paint);

    }


}
