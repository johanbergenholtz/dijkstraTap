package com.example.dijkstratap;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class LineVert extends View {
    Paint paint = new Paint();

    public LineVert(Context context) {

        super(context);
    }

    public LineVert(Context context, AttributeSet attrs) {

        super(context, attrs);
    }

    public LineVert(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas){
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(10f);
        canvas.drawLine(getWidth()/2,0,getWidth()/2,getHeight(), paint);

    }


}
