package com.example.dijkstratap;

public class Link{
    public int cost;
    public Router router1;
    public Router router2;
    //int neighbourLinkInd;
    public int neighbourID;

    public Link() {}

    public Link(int cost, Router router1,Router router2){
        this.cost = cost;
        this.router1 = router1;
        this.router2 = router2;
    }

    public boolean isSameLink(Link link) {
        return (this.router1.id == link.router1.id && this.router2.id == link.router2.id)
                || (this.router1.id == link.router2.id && this.router2.id == link.router1.id);
    }

}