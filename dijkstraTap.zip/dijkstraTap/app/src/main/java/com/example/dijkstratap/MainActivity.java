package com.example.dijkstratap;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    boolean rootSelect = true, stepChange = true;
    int size, step = 0, count = 0, lives = 3;
    Router root;
    leastCostPath[] currentPath ={};
    StringBuilder tableText;
    NumberedBtn[] btns;
    Router[] routers;
    Button currentBtn = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set up links and routers
        size = 7;
        routers = new Router[size];
        for (int i = 0; i < size; i++)
            routers[i] = new Router(i);

        Link[] links = createLinks();

        for (Router r : routers)
            r.createLinksFromArray(links);

        //set up router btns and give them id:s corresponding to router
        btns = new NumberedBtn[]{new NumberedBtn(findViewById(R.id.buttonA), 0),
                                 new NumberedBtn(findViewById(R.id.buttonB), 1),
                                 new NumberedBtn(findViewById(R.id.buttonC), 2),
                                 new NumberedBtn(findViewById(R.id.buttonD), 3),
                                 new NumberedBtn(findViewById(R.id.buttonE), 4),
                                 new NumberedBtn(findViewById(R.id.buttonF), 5),
                                 new NumberedBtn(findViewById(R.id.buttonG), 6)};

        for(NumberedBtn nBtn : btns){
            nBtn.btn.setBackgroundColor(Color.MAGENTA);
            nBtn.btn.setOnClickListener(e -> routerClick(nBtn));
        }

        // set up "find D(v)" display (invisible at start)
        TextView nodeToFind = findViewById(R.id.findNodeDisplay);
        nodeToFind.setTextColor(Color.RED);
        nodeToFind.setVisibility(View.GONE);

        //set up "current node: V" display (invisible at start)
        findViewById(R.id.currentNodeText).setVisibility(View.GONE);
        TextView letter = findViewById(R.id.currentNodeDisplay);
        letter.setTextColor(Color.BLUE);
        letter.setVisibility(View.GONE);

        //set up table and table text
        TextView tableBody = findViewById(R.id.tableBody);
        tableBody.setTextSize(10);
        tableText = new StringBuilder();

        TextView tableHead = findViewById(R.id.tableHead);
        tableHead.setTextSize(10);

        //set up infinity btn
        Button inf = findViewById(R.id.buttonInf);
        inf.setRotation(90);
        inf.setBackgroundColor(Color.YELLOW);
        inf.setTextColor(Color.DKGRAY);
        inf.setTextSize(25);
        inf.setOnClickListener(e -> infButtonClick(inf));

        // set up "no change" btn
        Button noChange = findViewById(R.id.buttonNoChange);
        noChange.setBackgroundColor(Color.LTGRAY);
        noChange.setTextColor(Color.DKGRAY);
        noChange.setOnClickListener(e -> noChangeButtonCLick(noChange));

        //set up restart btn
        Button restart = findViewById(R.id.buttonRestart);
        restart.setOnClickListener(e -> recreate());
    }

    //select some links randomly based on xml file
    private Link[] createLinks(){
        Random r = new Random();
        int max = 8; //max cost
        int minNbrOfLinks = 7;
        SuperLink[] linkList = {new SuperLink(findViewById(R.id.LineAB), findViewById(R.id.costAB),
                                        new Link(r.nextInt(max)+1,routers[0],routers[1])),
                                new SuperLink(findViewById(R.id.LineBC), findViewById(R.id.costBC),
                                        new Link(r.nextInt(max)+1,routers[1],routers[2])),
                                new SuperLink(findViewById(R.id.LineCD), findViewById(R.id.costCD),
                                        new Link(r.nextInt(max)+1,routers[2],routers[3])),
                                new SuperLink(findViewById(R.id.LineDF), findViewById(R.id.costDF),
                                        new Link(r.nextInt(max)+1,routers[3],routers[5])),
                                new SuperLink(findViewById(R.id.LineCE), findViewById(R.id.costCE),
                                        new Link(r.nextInt(max)+1,routers[2],routers[4])),
                                new SuperLink(findViewById(R.id.LineFG), findViewById(R.id.costFG),
                                        new Link(r.nextInt(max)+1,routers[5],routers[6])),
                                new SuperLink(findViewById(R.id.LineEG), findViewById(R.id.costEG),
                                        new Link(r.nextInt(max)+1,routers[4],routers[6])),
                                //OVANFÖR DENNA KOMMENTAR LIGGER DE LÄNKAR SOM ALLTID SKA LÄGGAS TILL
                                //LÄNKAR 0-6 (6 = minNbrOfLinks-1)
                                new SuperLink(findViewById(R.id.LineAE), findViewById(R.id.costAE),
                                        new Link(r.nextInt(max)+1,routers[0],routers[4])),
                                new SuperLink(findViewById(R.id.LineBD), findViewById(R.id.costBD),
                                        new Link(r.nextInt(max)+1,routers[1],routers[3])),
                                new SuperLink(findViewById(R.id.LineBE), findViewById(R.id.costBE),
                                        new Link(r.nextInt(max)+1,routers[1],routers[4])),
                                new SuperLink(findViewById(R.id.LineCF), findViewById(R.id.costCF),
                                        new Link(r.nextInt(max)+1,routers[2],routers[5])),
                                new SuperLink(findViewById(R.id.LineCG), findViewById(R.id.costCG),
                                        new Link(r.nextInt(max)+1,routers[2],routers[6]))
                                };
        Link[] temp = new Link[linkList.length];
        int index = 0, count = 0;

        for (SuperLink L : linkList){
            if (count < minNbrOfLinks || r.nextInt(10) < 4) {
                String costText = "" + L.link.cost;
                L.costDisplay.setText(costText);
                temp[index] = L.link;
                index++;
            }else{
                L.line.setVisibility(View.GONE);
                L.costDisplay.setVisibility(View.GONE);
            }
            count++;
        }

        Link[] links = new Link[index];
        if (index >= 0)
            System.arraycopy(temp, 0, links, 0, index);

        return links;
    }

    //Just a class to save line, cost display and link in same package
    private static class SuperLink{
        Link link;
        TextView costDisplay;
        View line;

        public SuperLink(View line, TextView costDisplay, Link link){
            this.link = link;
            this.line = line;
            this.costDisplay = costDisplay;
        }
    }

    private void routerClick(NumberedBtn nBtn){
        int id = nBtn.nbr;
        if (rootSelect){
            //save root
            root = routers[id];
            //Make button blue and as current button
            nBtn.btn.setBackgroundColor(Color.BLUE);
            currentBtn = nBtn.btn;
            //skapa dijkstra-facit
            root.dijkstraSolve(routers, size);
            //spara least-cost-path-facit för entry 0
            currentPath = root.getPathArray(step);
            //Skriv ut vilken som ska hittas härnäst
            TextView find = findViewById(R.id.selectOrFindText);
            find.setText("Find");
            findViewById(R.id.findNodeDisplay).setVisibility(View.VISIBLE);
            changeInstruction();
            //Skapa tabell
            TextView tableHead = findViewById(R.id.tableHead);
            tableHead.setText(tableOverHead(size,id));
            updateTable();
            //Skriv ut vilken node som är nuvarande (root)
            findViewById(R.id.currentNodeText).setVisibility(View.VISIBLE);
            findViewById(R.id.currentNodeDisplay).setVisibility(View.VISIBLE);
            setCurrentNodeDisplay(id);
            rootSelect = false;
            return;
        }

        if (id == root.id || nBtn.isBlue || lives == 0)
            return;

        if (root.guess(id, step, count)){
            nBtn.btn.setBackgroundColor(Color.GREEN);
            updateGame();
            if (!nBtn.isBlue)
                changeBackColorAfter1s(nBtn.btn, Color.MAGENTA);
            return;
        }

        //Om kostnaden till den här noden är lika med facit
        //vill vi inte ge fel, så vi låtsas som om användaren
        //klickat på noChange-knappen istället
        if (pathIsValidAnyway(id)){
            noChangeButtonCLick(findViewById(R.id.buttonNoChange));
            return;
        }

        nBtn.btn.setBackgroundColor(Color.RED);
        changeBackColorAfter1s(nBtn.btn, Color.MAGENTA);
        takeALife();
    }

    private void takeALife() {
        if (lives == 0)
            return;
        lives--;
        String s = "" + lives;
        TextView livesD = findViewById(R.id.LivesDisplay);
        livesD.setText(s);
        if (lives == 0)
            death();
    }

    //Den här koden är ett desperat hafsverk
    private boolean pathIsValidAnyway(int idOfGoal){
        if (step == 0)
            return false;
        dijkstraEntry currentEntry = root.dijkstraTable[step];
        Router currentRouter = routers[currentEntry.currentNodeID];

        int indexOfCurrent = currentEntry.findIndexOfRouterInPath(currentRouter.id);
        if (indexOfCurrent < 0)
            return false;
        int costToCurrent = currentPath[indexOfCurrent].cost;
        //Länken mellan nuvarande router och den vi klickade på.
        //Om kostnaden på denna länk + kostnaden till vår currentRouter
        //är samma som i facit, så returnerar vi true
        Link l = currentRouter.findLinkToRouter(idOfGoal);
        return l != null && l.cost + costToCurrent == currentPath[count].cost;
    }

    private void updateGame(){
        if (lives == 0)
            return;
        if (step == size-1) {
            tableText.append("                  ALLES GEFUNDEN!!");
            TextView t = findViewById(R.id.tableBody);
            t.setText(tableText);
            currentBtn.setTextColor(getResources().getColor(R.color.lGreen));
            findViewById(R.id.LivesDisplay).setVisibility(View.GONE);
            findViewById(R.id.LivesLabel).setVisibility(View.GONE);
            findViewById(R.id.selectOrFindText).setVisibility(View.GONE);
            findViewById(R.id.findNodeDisplay).setVisibility(View.GONE);
            findViewById(R.id.currentNodeText).setVisibility(View.GONE);
            findViewById(R.id.currentNodeDisplay).setVisibility(View.GONE);
            return;
        }
        updateTable();
        count++;
        if (count == size - 1) {
            step++;
            stepChange = true;
            currentPath = root.getPathArray(step);
            if (currentBtn != null)
                currentBtn.setTextColor(getResources().getColor(R.color.lGreen));
            NumberedBtn nextNode = getNbrButton(root.dijkstraTable[step].currentNodeID);
            if (nextNode != null) {
                nextNode.btn.setBackgroundColor(Color.BLUE);
                nextNode.isBlue = true;
                setCurrentNodeDisplay(nextNode.nbr);
                currentBtn = nextNode.btn;
            }
            count = count % (size-1);
            updateTable();
        }

        changeInstruction();
        NumberedBtn nextInPath = getNbrButton(currentPath[count].destRouter.id);
        if (nextInPath != null && nextInPath.isBlue)
            updateGame();
    }

    private void updateTable(){
        TextView tableBody = findViewById(R.id.tableBody);
        if (stepChange){
            tableText.append("\n    ");
            tableText.append(step);
            tableText.append("      ");
            for (Router r : root.dijkstraTable[step].N){
                tableText.append((char) ('A' + r.id));
                tableText.append(",");
            }
            tableText.deleteCharAt(tableText.length() - 1);
            tableText.append("                  ");
            for (int i = 0; i < step; i++){
                tableText.deleteCharAt(tableText.length() - 1);
                tableText.deleteCharAt(tableText.length() - 1);
                tableText.deleteCharAt(tableText.length() - 1);
            }
            stepChange = false;
        } else if (root.isInfinity(step,count)){
            tableText.append("inf");
            tableText.append("           ");
        } else {
            tableText.append(currentPath[count].cost);
            tableText.append(",");
            tableText.append((char)('A' + currentPath[count].predecessor.id));
            tableText.append("          ");
            if (currentPath[count].cost > 9) {
                tableText.deleteCharAt(tableText.length() - 1);
                tableText.deleteCharAt(tableText.length() - 1);
            }
        }

        tableBody.setText(tableText.toString());
    }

    private void infButtonClick(Button btn){
        if (rootSelect || lives == 0)
            return;

        if (root.isInfinity(step, count)){
            btn.setBackgroundColor(Color.GREEN);
            changeBackColorAfter1s(btn, Color.YELLOW);
            updateGame();
            return;
        }

        btn.setBackgroundColor(Color.RED);
        changeBackColorAfter1s(btn, Color.YELLOW);
        takeALife();
    }

    private void noChangeButtonCLick(Button btn){
        if (rootSelect || lives == 0)
            return;

        if (root.isSameCostAsLastTime(step, count)){
            btn.setBackgroundColor(Color.GREEN);
            changeBackColorAfter1s(btn, Color.LTGRAY);
            updateGame();
            return;
        }
        btn.setBackgroundColor(Color.RED);
        changeBackColorAfter1s(btn, Color.LTGRAY);
        takeALife();
    }

    //Found at https://stackoverflow.com/questions/15874117/how-to-set-delay-in-android
    // Thanks to Sufiyan Ghori
    private void changeBackColorAfter1s(Button btn, int color){
        new CountDownTimer(1000, 1000){
            public void onFinish(){
                btn.setBackgroundColor(color);
            }
            public void onTick(long millisUntilFinished){}
        }.start();
    }

    private void changeInstruction() {
        String letter = currentValueString(currentPath[count].destRouter.id);
        TextView display = findViewById(R.id.findNodeDisplay);
        display.setText(letter);
    }

    private static String currentValueString(int id){
        return "D(" + (char) ('A' + id) + ")";
    }

    private static class NumberedBtn{
        public Button btn;
        public int nbr;
        public boolean isBlue = false;
        public NumberedBtn(Button btn, int id){
            this.btn = btn;
            nbr = id;
        }
    }

    private NumberedBtn getNbrButton(int id){
        for (NumberedBtn btn : btns){
            if (btn.nbr == id)
                return btn;
        }
        return null;
    }

    private void setCurrentNodeDisplay(int id){
        TextView letter = findViewById(R.id.currentNodeDisplay);
        String l = "" + (char) ('A'+id);
        letter.setText(l);
    }

    private static String tableOverHead(int size, int rootIndex){
        StringBuilder s = new StringBuilder();
        s.append("STEP         N'     ");

        for (int i = 0; i < size; i++){
            if (i != rootIndex) {
                s.append("      D(");
                s.append((char) ('A' + i));
                s.append("),");
            }
        }

        s.append("\n                            ");

        for (int i = 0; i < size; i++){
            if (i != rootIndex) {
                s.append("      p(");
                s.append((char) ('A' + i));
                s.append(") ");
            }
        }
        return s.toString();
    }

    private void death(){
        TextView table = findViewById(R.id.tableBody);
        table.setTextColor(Color.RED);
        findViewById(R.id.currentNodeDisplay).setVisibility(View.GONE);
        findViewById(R.id.currentNodeText).setVisibility(View.GONE);
        findViewById(R.id.findNodeDisplay).setVisibility(View.GONE);
        TextView message = findViewById(R.id.selectOrFindText);
        message.setTextColor(Color.RED);
        message.setText("DEAD");
        TextView livesDisplay = findViewById(R.id.LivesDisplay);
        livesDisplay.setTextColor(Color.RED);
    }
}