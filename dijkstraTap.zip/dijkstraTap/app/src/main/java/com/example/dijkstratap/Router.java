package com.example.dijkstratap;


import java.util.HashSet;


public class Router {
    //Alla attribut är publika för vi har inget att dölja
    // + vi orkar inte skriva massa get-metoder
    public Link[] links;
    public int nbrOfLinks;
    public int id;
    public dijkstraEntry[] dijkstraTable;

    public Router (int id) {
        this.id = id;
        nbrOfLinks = 0;
        links = null;
    }

    //För att skapa routerns interna link array från en extern array av länkar med två routrar på varsin ända
    public void createLinksFromArray(Link[] linkArray) {
        if (nbrOfLinks != 0) { //Vi skapar en ny array om det redan finns en gammal
            links = null;
            nbrOfLinks = 0;
        }
        Link[] temp = new Link[linkArray.length];
        int size = 0;
        for (Link l : linkArray) {//Kollar för varje om en av routrarna i externa arrayens element matchar
            if (l.router1.id == id || l.router2.id == id) {
                temp[size] = new Link();
                temp[size].router1 = this;
                temp[size].router2 = l.router1.id == id ? l.router2 : l.router1;
                temp[size].neighbourID = l.router1.id == id ? l.router2.id : l.router1.id;
                temp[size].cost = l.cost;
                ++size;
            }
        }
        nbrOfLinks = size;
        links = new Link[nbrOfLinks];
        if (nbrOfLinks >= 0) System.arraycopy(temp, 0, links, 0, nbrOfLinks);
    }

    @Override
    public boolean equals(Object obj) {

        if (obj instanceof Router) {
            Router r = (Router) obj;
            return id == r.id;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return id;
    }

    public void dijkstraSolve(Router[] routers, int nbrOfRouters) {
        dijkstraTable = new dijkstraEntry[nbrOfRouters];
        int step = 0;
        HashSet<Router> N = new HashSet<>();
        N.add(this);
        leastCostPath[] pathArray = new leastCostPath[nbrOfRouters-1];
        leastCostPath cheapest = new leastCostPath();
        cheapest.cost = Integer.MAX_VALUE;
        //initialize
        int j = 0;
        for (int i = 0; i < nbrOfRouters; i++) {

            if (routers[i].id == this.id)
                continue;

            boolean success = false;
            for (Link l : links) {
                if (l.router2.id == routers[i].id) {
                    pathArray[j] = new leastCostPath(routers[i], l.cost, this);
                    success = true;
                    cheapest = l.cost < cheapest.cost ? new leastCostPath(routers[i], l.cost) : cheapest;
                    break;
                }
            }

            if (!success)
                pathArray[j] = new leastCostPath(routers[i], Integer.MAX_VALUE);


            j++;
        }

        dijkstraTable[step] = new dijkstraEntry(step, N, pathArray);

        // rest of dijkstra
        while (N.size() < nbrOfRouters) {
            Router currentNode = cheapest.destRouter;
            int currentCost = cheapest.cost;
            N.add(currentNode);
            step++;
            cheapest = new leastCostPath();
            cheapest.cost = Integer.MAX_VALUE;

            for (int i = 0; i < nbrOfRouters-1; i++) {
                if (N.contains(pathArray[i].destRouter))
                    continue;
                for (Link l : currentNode.links) {
                    if (l.router2.id == pathArray[i].destRouter.id && currentCost + l.cost < pathArray[i].cost) {
                        pathArray[i].cost = currentCost + l.cost;
                        pathArray[i].predecessor = currentNode;
                        break;
                    }
                }
                cheapest = pathArray[i].cost < cheapest.cost ? pathArray[i] : cheapest;
            }
            dijkstraTable[step] = new dijkstraEntry(step, N, pathArray);
            dijkstraTable[step].currentNodeID = currentNode.id; //Behövs i main
        }

    }

    // gives back a link to a router with id
    // (from the internal links from which the router is called)
    public Link findLinkToRouter(int id){
        for (Link l : links){
            if (l.router1.id == id || l.router2.id == id)
                return l;
        }
        return null;
    }

    public boolean guess(int idGuess, int step, int pathArrayInd) {
        leastCostPath[] a = dijkstraTable[step].pathArray;
        return a[pathArrayInd].destRouter.id == idGuess && a[pathArrayInd].cost < Integer.MAX_VALUE
                                                        && !isSameCostAsLastTime(step, pathArrayInd);
    }

    public boolean isInfinity(int step, int pathArrayInd){
        return dijkstraTable[step].pathArray[pathArrayInd].cost == Integer.MAX_VALUE;
    }

    public boolean isSameCostAsLastTime(int step, int pathArrayInd){
        return step != 0 && dijkstraTable[step].pathArray[pathArrayInd].cost ==
                            dijkstraTable[step-1].pathArray[pathArrayInd].cost;
    }

    public leastCostPath[] getPathArray(int step){
        return dijkstraTable[step].pathArray;
    }
}