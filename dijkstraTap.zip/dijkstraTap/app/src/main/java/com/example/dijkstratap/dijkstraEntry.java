package com.example.dijkstratap;

import java.util.HashSet;


public class dijkstraEntry {
    public int step, currentNodeID;
    public HashSet<Router> N;
    public leastCostPath[] pathArray;

    public dijkstraEntry(int step, HashSet<Router> N, leastCostPath[] pathArray) {
        this.step = step;
        this.N = new HashSet<>();
        this.N.addAll(N);
        int size = pathArray.length;
        this.pathArray = new leastCostPath[size];
        for (int i = 0; i < size; i++) {
            this.pathArray[i] = new leastCostPath(pathArray[i].destRouter,
                                                  pathArray[i].cost,
                                                  pathArray[i].predecessor);
        }
    }

    // can find index of router with id in path array
    public int findIndexOfRouterInPath(int id){
        for (int i = 0; i < pathArray.length; i++){
            if (pathArray[i].destRouter.id == id)
                return i;
        }
        return -1;
    }
}
