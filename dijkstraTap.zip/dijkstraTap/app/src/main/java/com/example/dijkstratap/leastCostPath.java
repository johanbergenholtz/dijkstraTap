package com.example.dijkstratap;

public class leastCostPath {
    public int cost;
    public Router predecessor;
    public Router destRouter;

    public leastCostPath(Router destRouter, int cost, Router predecessor) {
        this.destRouter = destRouter;
        this.cost = cost;
        this.predecessor = predecessor;
    }

    public leastCostPath(Router destRouter, int cost) {
        this.destRouter = destRouter;
        this.cost = cost;
    }

    public leastCostPath() {}
}
